import { View, Text } from 'react-native'
import React from 'react'

export default function Categories() {
  return (
    <View>
      <Text>Update Category</Text>
    </View>
  )
}