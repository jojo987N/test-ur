
export const APP_CONSTANT = {

    ORDER_ID: "Order ID",
    ADDRESS: "Address",
    CONFIRMED: "confirmed",
    STATUS: "Status",
    PENDING: "pending",
    PRICE: "price"
}


export const language = "en"
export const currency = "USD"


